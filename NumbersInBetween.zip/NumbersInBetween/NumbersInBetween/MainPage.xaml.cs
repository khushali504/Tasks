﻿using System;
using Microsoft.Maui.Controls;

namespace NumbersInBetween
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnGenerateClicked(object sender, EventArgs e)
        {
            // Get user inputs
            if (!int.TryParse(StartNumberEntry.Text, out int startNumber) ||
                !int.TryParse(EndNumberEntry.Text, out int endNumber) ||
                !int.TryParse(IncrementEntry.Text, out int increment))
            {
                DisplayAlert("Error", "Please enter valid numeric values.", "OK");
                return;
            }

            // Ensure increment is valid
            if (increment <= 0)
            {
                DisplayAlert("Error", "Increment value must be greater than zero.", "OK");
                return;
            }

            // Ensure range is valid
            if (startNumber > endNumber)
            {
                DisplayAlert("Error", "Start number should be less than or equal to the end number.", "OK");
                return;
            }

            // Generate numbers
            string result = "Numbers in between:\n";
            for (int i = startNumber; i <= endNumber; i += increment)
            {
                result += i + "\n";
            }

            // Display result
            ResultLabel.Text = result;
        }
    }
}
