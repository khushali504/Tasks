﻿using Microsoft.Maui.Controls;
using System;

namespace VowelIdentifier
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCheckClicked(object sender, EventArgs e)
        {
            string input = LetterEntry.Text?.Trim(); // Get input text

            // Validate input: Ensure it's a single letter
            if (string.IsNullOrEmpty(input) || input.Length != 1 || !char.IsLetter(input[0]))
            {
                ResultLabel.Text = "❌ Please enter a valid letter.";
                ResultLabel.TextColor = Colors.Red;
                ResultLabel.IsVisible = true;
                return;
            }

            char letter = char.ToLower(input[0]); // Convert to lowercase

            // Check if the letter is a vowel
            bool isVowel = "aeiou".Contains(letter);

            // Display the result
            ResultLabel.Text = isVowel ? "✅ Vowel" : "❌ Not a vowel";
            ResultLabel.TextColor = isVowel ? Colors.Green : Colors.Red;
            ResultLabel.IsVisible = true;

            // Show the "Try Again" button
            TryAgainButton.IsVisible = true;
            LetterEntry.IsEnabled = false;
        }

        private void OnTryAgainClicked(object sender, EventArgs e)
        {
            // Reset UI for new input
            LetterEntry.Text = "";
            LetterEntry.IsEnabled = true;
            ResultLabel.IsVisible = false;
            TryAgainButton.IsVisible = false;
        }
    }
}
