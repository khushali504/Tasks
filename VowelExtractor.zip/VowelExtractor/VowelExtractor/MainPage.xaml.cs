﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Maui.Controls;

namespace VowelExtractor
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnExtractClicked(object sender, EventArgs e)
        {
            string inputWord = wordEntry.Text?.Trim().ToLower();
            if (string.IsNullOrEmpty(inputWord))
            {
                DisplayAlert("Error", "Please enter a word", "OK");
                return;
            }

            char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
            Dictionary<char, int> vowelCounts = new Dictionary<char, int>();
            string wordWithoutVowels = "";

            foreach (char c in inputWord)
            {
                if (vowels.Contains(c))
                {
                    if (vowelCounts.ContainsKey(c))
                        vowelCounts[c]++;
                    else
                        vowelCounts[c] = 1;
                }
                else
                {
                    wordWithoutVowels += c;
                }
            }

            vowelListLabel.Text = vowelCounts.Count == 0 ? "No vowels found"
                              : string.Join("\n", vowelCounts.Select(v => $"{v.Key}: {v.Value} times"));

            wordWithoutVowelsLabel.Text = string.IsNullOrEmpty(wordWithoutVowels) ? "No consonants found" : wordWithoutVowels;
        }
    }
}
