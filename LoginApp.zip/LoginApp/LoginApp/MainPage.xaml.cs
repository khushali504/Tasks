﻿using Microsoft.Maui.Controls;
using System;

namespace LoginApp
{
    public partial class MainPage : ContentPage
    {
        private string correctPassword;
        private string passwordHint;
        private int attemptsLeft = 5;

        // List of words to generate a random password (Bonus Feature)
        private readonly string[] wordList = { "Apple", "Tiger", "River", "Sun", "Green", "Moon", "Sky", "Ocean" };

        public MainPage()
        {
            InitializeComponent();
            GenerateRandomPassword(); // Generate password on startup
        }

        private void GenerateRandomPassword()
        {
            Random rnd = new Random();
            string word1 = wordList[rnd.Next(wordList.Length)];
            string word2 = wordList[rnd.Next(wordList.Length)];
            correctPassword = word1 + word2; // Randomly generated password
            passwordHint = $"Hint: {word1.Substring(0, 2)}... {word2.Substring(0, 2)}..."; // Show hint
            HintLabel.Text = passwordHint;
        }

        private void OnLoginClicked(object sender, EventArgs e)
        {
            string enteredPassword = PasswordEntry.Text;

            if (attemptsLeft > 0)
            {
                if (enteredPassword == correctPassword)
                {
                    ResultLabel.Text = "✅ Welcome!";
                    ResultLabel.TextColor = Colors.Green;
                    PasswordEntry.IsEnabled = false;
                }
                else
                {
                    attemptsLeft--;
                    ResultLabel.Text = $"❌ Incorrect password. Attempts left: {attemptsLeft}";
                    ResultLabel.TextColor = Colors.Red;

                    if (attemptsLeft == 0)
                    {
                        ResultLabel.Text = "🔒 You have been locked out.";
                        PasswordEntry.IsEnabled = false;
                    }
                }
            }
        }
    }
}
