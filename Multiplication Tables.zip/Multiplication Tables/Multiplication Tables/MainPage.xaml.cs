﻿using Microsoft.Maui.Controls;

namespace Multiplication_Tables
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnGenerateClicked(object sender, EventArgs e)
        {
            ResultLabel.Text = "";

            if (!int.TryParse(NumberEntry.Text, out int number) || number < -50 || number > 50)
            {
                ResultLabel.Text = "Please enter a valid number between -50 and 50!";
                return;
            }

            int limit = 12;
            if (int.TryParse(LimitEntry.Text, out int customLimit) && customLimit > 0)
            {
                limit = customLimit;
            }

            for (int i = 1; i <= limit; i++)
            {
                ResultLabel.Text += $"{number} × {i} = {number * i}\n";
            }
        }
    }
}
