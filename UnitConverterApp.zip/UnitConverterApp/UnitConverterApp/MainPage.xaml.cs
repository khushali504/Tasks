﻿namespace UnitConverterApp
{
    public partial class MainPage : ContentPage
    {
        private readonly Dictionary<string, double> speedConversion = new()
        {
            { "MPH to KPH", 1.60934 },
            { "KPH to MPH", 0.621371 },
            { "MPS to KPH", 3.6 },
            { "KPH to MPS", 0.277778 }
        };

        private readonly Dictionary<string, double> distanceConversion = new()
        {
            { "Miles to Kilometers", 1.60934 },
            { "Kilometers to Miles", 0.621371 },
            { "Feet to Meters", 0.3048 },
            { "Meters to Feet", 3.28084 }
        };

        private string selectedType = "Speed";

        public MainPage()
        {
            InitializeComponent();
            PopulateUnitPickers();
        }

        private void OnTypeChanged(object sender, EventArgs e)
        {
            selectedType = TypePicker.SelectedItem.ToString();
            PopulateUnitPickers();
        }

        private void PopulateUnitPickers()
        {
            FromUnitPicker.Items.Clear();
            ToUnitPicker.Items.Clear();

            var units = selectedType == "Speed" ? speedConversion.Keys : distanceConversion.Keys;

            foreach (var unit in units)
            {
                string[] parts = unit.Split(" to ");
                if (!FromUnitPicker.Items.Contains(parts[0]))
                {
                    FromUnitPicker.Items.Add(parts[0]);
                }
                if (!ToUnitPicker.Items.Contains(parts[1]))
                {
                    ToUnitPicker.Items.Add(parts[1]);
                }
            }
        }

        private void OnConvertClicked(object sender, EventArgs e)
        {
            if (FromUnitPicker.SelectedItem == null || ToUnitPicker.SelectedItem == null)
            {
                ResultLabel.Text = "Please select units.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            if (!double.TryParse(ValueEntry.Text, out double inputValue))
            {
                ResultLabel.Text = "Enter a valid number.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            string fromUnit = FromUnitPicker.SelectedItem.ToString();
            string toUnit = ToUnitPicker.SelectedItem.ToString();
            string conversionKey = fromUnit + " to " + toUnit;

            double result = 0;
            if (speedConversion.ContainsKey(conversionKey))
            {
                result = inputValue * speedConversion[conversionKey];
            }
            else if (distanceConversion.ContainsKey(conversionKey))
            {
                result = inputValue * distanceConversion[conversionKey];
            }
            else
            {
                ResultLabel.Text = "Invalid conversion.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            ResultLabel.Text = $"{inputValue} {fromUnit} = {result:F2} {toUnit}";
            ResultLabel.TextColor = Colors.Green;
        }
    }
}
