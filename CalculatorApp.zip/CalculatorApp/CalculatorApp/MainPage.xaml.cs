﻿namespace CalculatorApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            if (!double.TryParse(FirstNumberEntry.Text, out double firstNumber))
            {
                ResultLabel.Text = "Invalid first number.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            if (!double.TryParse(SecondNumberEntry.Text, out double secondNumber))
            {
                ResultLabel.Text = "Invalid second number.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            if (OperatorPicker.SelectedItem == null)
            {
                ResultLabel.Text = "Please select an operator.";
                ResultLabel.TextColor = Colors.Red;
                return;
            }

            string operation = OperatorPicker.SelectedItem.ToString();
            double result = 0;
            bool isValidOperation = true;

            switch (operation)
            {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber == 0)
                    {
                        ResultLabel.Text = "Cannot divide by zero.";
                        ResultLabel.TextColor = Colors.Red;
                        return;
                    }
                    result = firstNumber / secondNumber;
                    break;
                default:
                    isValidOperation = false;
                    break;
            }

            if (!isValidOperation)
            {
                ResultLabel.Text = "Invalid operation.";
                ResultLabel.TextColor = Colors.Red;
            }
            else
            {
                ResultLabel.Text = $"Result: {result:F2}";
                ResultLabel.TextColor = Colors.Green;
            }
        }
    }
}
