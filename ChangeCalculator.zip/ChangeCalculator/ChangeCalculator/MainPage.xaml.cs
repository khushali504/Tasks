﻿using System;
using Microsoft.Maui.Controls;

namespace ChangeCalculator
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            // Get input values
            if (!decimal.TryParse(PriceEntry.Text, out decimal price) ||
                !decimal.TryParse(PaidEntry.Text, out decimal paidAmount))
            {
                DisplayAlert("Error", "Please enter valid numeric values.", "OK");
                return;
            }

            // Ensure paid amount is greater than or equal to the price
            if (paidAmount < price)
            {
                DisplayAlert("Error", "Amount paid is less than the price!", "OK");
                return;
            }

            // Calculate change and round to nearest 5 cents
            decimal change = paidAmount - price;
            change = Math.Round(change * 20) / 20;

            // Convert to cents for accurate calculations
            int remainingCents = (int)(change * 100);

            // Canadian denominations (in cents)
            int[] denominations = { 10000, 5000, 2000, 1000, 500, 200, 100, 25, 10, 5 };
            string[] names = { "100 Dollar Bill", "50 Dollar Bill", "20 Dollar Bill", "10 Dollar Bill",
                               "5 Dollar Bill", "2 Dollar Coin", "1 Dollar Coin",
                               "25 Cent Coin", "10 Cent Coin", "5 Cent Coin" };

            int[] count = new int[denominations.Length];

            // Calculate optimal change breakdown
            for (int i = 0; i < denominations.Length; i++)
            {
                count[i] = remainingCents / denominations[i];
                remainingCents %= denominations[i];
            }

            // Display the result
            string result = $"Total Change: ${change:F2}\n";
            for (int i = 0; i < denominations.Length; i++)
            {
                if (count[i] > 0)
                {
                    result += $"{count[i]} x {names[i]}\n";
                }
            }

            ChangeLabel.Text = result;
        }
    }
}
